import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import '../utils/auth_utils.dart';
import '../student_details_page.dart';
import 'package:earn_and_learn_project/work_request.dart';
class SubCoordinatorDashboard extends StatefulWidget {
  final String uid;

  const SubCoordinatorDashboard({super.key, required this.uid});

  @override
  State<SubCoordinatorDashboard> createState() =>
      _SubCoordinatorDashboardState();
}

class _SubCoordinatorDashboardState
    extends State<SubCoordinatorDashboard>
    with SingleTickerProviderStateMixin {

  late DatabaseReference _subRef;
  final DatabaseReference _usersRef =
      FirebaseDatabase.instance.ref("users");

  Map<String, dynamic>? subData;
  StreamSubscription? _subscription;

  List<Map<String, dynamic>> allEntries = [];
  List<Map<String, dynamic>> uniqueStudents = [];

  bool isLoading = true;
  String searchQuery = "";

  late TabController _tabController;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 2, vsync: this);

    _subRef =
        FirebaseDatabase.instance.ref("users/${widget.uid}");

    _subRef.once().then((snapshot) {
      if (snapshot.snapshot.value != null) {
        setState(() {
          subData = Map<String, dynamic>.from(
              snapshot.snapshot.value as Map);
        });

        _listenToEntries();
      }
    });
  }

  void _updateWorkStatus(String uid, String title, String status) {
    final userRef = _usersRef.child(uid).child("workEntries");

    userRef.once().then((snapshot) {
      if (snapshot.snapshot.value == null) return;

      final works =
          Map<String, dynamic>.from(snapshot.snapshot.value as Map);

      works.forEach((key, workRaw) {
        final work = Map<String, dynamic>.from(workRaw);
        if (work["title"] == title) {
          userRef.child(key).update({"status": status});
        }
      });
    });
  }

  void _listenToEntries() {
    final subDept =
        (subData?["department"] ?? "").toString().toLowerCase();

    _subscription = _usersRef.onValue.listen((event) {
      final List<Map<String, dynamic>> entriesList = [];
      final Map<String, Map<String, dynamic>> studentsMap = {};

      if (event.snapshot.value != null) {
        final users =
            Map<String, dynamic>.from(event.snapshot.value as Map);

        users.forEach((uid, userRaw) {
          final user = Map<String, dynamic>.from(userRaw);
          final dept =
              (user["department"] ?? "").toString().toLowerCase();

          if (dept != subDept) return;

          double totalHours = 0;

          if (user["workEntries"] != null) {
            final workEntries =
                Map<String, dynamic>.from(user["workEntries"]);

            workEntries.forEach((_, workRaw) {
              final work = Map<String, dynamic>.from(workRaw);

              totalHours +=
                  double.tryParse(work["hours"]?.toString() ?? "0") ?? 0;

              entriesList.add({
                "uid": uid,
                "name": user["name"],
                "email": user["email"],
                "mobile": user["mobile"] ?? "-",
                "department": user["department"],
                "title": work["title"],
                "hours": work["hours"],
                "date": work["date"],
                "status": work["status"],
              });
            });
          }

          studentsMap[uid] = {
            "uid": uid,
            "name": user["name"],
            "email": user["email"],
            "mobile": user["mobile"] ?? "-",
            "totalHours": totalHours,
          };
        });
      }

      setState(() {
        allEntries = entriesList;
        uniqueStudents = studentsMap.values.toList();
        isLoading = false;
      });
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    final pendingEntries = allEntries
        .where((e) =>
            e["status"]?.toString().toLowerCase() == "pending")
        .toList();

    return Scaffold(
      backgroundColor: const Color(0xFF0B1E3D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B1E3D),
        foregroundColor: Colors.white,
        title: const Text("Sub-Coordinator Dashboard",
            style: TextStyle(fontWeight: FontWeight.bold)),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              AuthUtils.showLogoutDialog(context);
            },
          ),
        ],
      ),
      body: Column(
        children: [

          /// PROFILE CARD
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFF1B3A68), Color(0xFF0B1E3D)]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white24,
                    child: Text(
                      subData?["name"] != null
                          ? subData!["name"][0]
                          : "S",
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(subData?["name"] ?? "",
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                        Text(subData?["email"] ?? "",
                            style: const TextStyle(
                                color: Colors.white70)),
                        Text(subData?["department"] ?? "",
                            style: const TextStyle(
                                color: Colors.white70)),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),

          /// NEW REQUESTS
          Expanded(
            child: isLoading
                ? const Center(
                    child: CircularProgressIndicator())
                : pendingEntries.isEmpty
                    ? const Center(
                        child: Text("No Pending Requests",
                            style: TextStyle(
                                color: Colors.white70)))
                    : ListView.builder(
                        itemCount: pendingEntries.length,
                        itemBuilder: (context, index) {
                          final e = pendingEntries[index];

                          return WorkRequestCard(
                            workData: e,
                            onApprove: () {
                              _updateWorkStatus(
                                  e["uid"],
                                  e["title"],
                                  "approved_by_sub");
                            },
                            onReject: () {
                              _updateWorkStatus(
                                  e["uid"],
                                  e["title"],
                                  "rejected");
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
