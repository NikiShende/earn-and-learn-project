// import 'dart:async';
// import 'studworkdetails.dart';
// import 'package:flutter/material.dart';
// import 'package:firebase_database/firebase_database.dart';
// import 'package:earn_and_learn_project/loginpage.dart';
// import '../utils/auth_utils.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// class HodDashboard extends StatefulWidget {
//   final Map hodData;
//   final String uid;

//   const HodDashboard({super.key, required this.hodData, required this.uid});

//   @override
//   State<HodDashboard> createState() => _HodDashboardState();
// }

// class _HodDashboardState extends State<HodDashboard>
//     with SingleTickerProviderStateMixin {
//   final DatabaseReference _usersRef = FirebaseDatabase.instance.ref("users");
//   StreamSubscription? _subscription;
// void _updateWorkStatus(String uid, String title, String status) {
//   final userRef = _usersRef.child(uid).child("workEntries");
//   userRef.once().then((snapshot) {
//     final works = Map<String, dynamic>.from(snapshot.snapshot.value as Map);
//     works.forEach((key, workRaw) {
//       final work = Map<String, dynamic>.from(workRaw);
//       if (work["title"] == title) {
//         userRef.child(key).update({"status": status});
//       }
//     });
//   });
// }

//   List<Map<String, dynamic>> allEntries = [];
//   List<Map<String, dynamic>> uniqueStudents = [];
//   bool isLoading = true;
//   String searchQuery = "";

//   late TabController _tabController;

//   @override
//   void initState() {
//     super.initState();
//     _tabController = TabController(length: 2, vsync: this);
//     _listenToHodEntries(
      
//     );
//   }

//   void _listenToHodEntries() {
//     final hodDept =
//     (widget.hodData["department"] ?? "")
//         .toString()
//         .trim()
//         .toLowerCase();


//     _subscription = _usersRef.onValue.listen((event) {
//       final List<Map<String, dynamic>> entriesList = [];
//       final Map<String, Map<String, dynamic>> studentsMap = {};

//       if (event.snapshot.value != null) {
//         final users = Map<String, dynamic>.from(event.snapshot.value as Map);
//         users.forEach((uid, userRaw) {
//           final user = Map<String, dynamic>.from(userRaw);
//           final dept =
//     (user["department"] ?? "")
//         .toString()
//         .trim()
//         .toLowerCase();

//          if (dept.trim().toLowerCase() != hodDept.trim().toLowerCase()) return;

// print("HOD Department: $hodDept");
// print("Student Department: $dept");

//           // Calculate total work hours for the student
//           double totalHours = 0;
//           if (user["workEntries"] != null) {
//             final workEntries = Map<String, dynamic>.from(user["workEntries"]);
//             workEntries.forEach((_, workRaw) {
//               final work = Map<String, dynamic>.from(workRaw);
//               totalHours += double.tryParse(work["hours"]?.toString() ?? "0") ?? 0;
//               entriesList.add({
//                 "uid": uid,
                
//                 "name": user["name"],
//                 "email": user["email"],
//                 "mobile": user["mobile"] ?? "-",
//                 "department": user["department"],
//                 "title": work["title"],
//                 "hours": work["hours"] ?? 0,
//                 "fromTime": work["fromTime"],
//                 "toTime": work["toTime"],
//                 "workplace": work["workplace"],
//                 "date": work["date"],
//                 "status": work["status"],
//               });
//             });
//           }

//           // Store unique student with total work hours
//           studentsMap[uid] = {
//             "uid": uid,
//             "name": user["name"],
//             "email": user["email"],
//             "mobile": user["mobile"] ?? "-",
//             "totalHours": totalHours,
//           };
//         });
//       }

//       setState(() {
//         allEntries = entriesList;
//         uniqueStudents = studentsMap.values.toList();
//         isLoading = false;
//       });
//     });
//   }

//   @override
//   void dispose() {
//     _subscription?.cancel();
//     _tabController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final pendingEntries = allEntries
//         .where((e) =>
//             e["status"]?.toString().toLowerCase() == "pending" &&
//             (e["name"] ?? "")
//                 .toString()
//                 .toLowerCase()
//                 .contains(searchQuery.toLowerCase()))
//         .toList();

//     final totalStudents = uniqueStudents.length;
//     final pendingCount = pendingEntries.length;

//     return Scaffold(
//       backgroundColor: const Color(0xFF0B1E3D),
//       appBar: AppBar(
//         backgroundColor: const Color(0xFF0B1E3D),
//         foregroundColor: Colors.white,
//         title: Text("HOD's Dashboard",style: TextStyle(fontWeight: FontWeight.bold),),
//         automaticallyImplyLeading: false,
//       ),
//       body: SafeArea(
//         child: Column(
//           children: [
//             // HOD Profile Card
//             Padding(
//               padding: const EdgeInsets.all(16),
//               child: Container(
//                 padding: const EdgeInsets.all(16),
//                 decoration: BoxDecoration(
//                   gradient: const LinearGradient(
//                       colors: [Color(0xFF1B3A68), Color(0xFF0B1E3D)]),
//                   borderRadius: BorderRadius.circular(20),
//                   boxShadow: const [
//                     BoxShadow(
//                         color: Colors.black45,
//                         blurRadius: 10,
//                         offset: Offset(0, 4))
//                   ],
//                 ),
//                 child: Row(
//                   children: [
//                     CircleAvatar(
//                       radius: 30,
//                       backgroundColor: Colors.white24,
//                       child: Text(
//                         widget.hodData["name"]?.toString().substring(0, 1) ??
//                             "H",
//                         style: const TextStyle(
//                             fontSize: 24,
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white),
//                       ),
//                     ),
//                     const SizedBox(width: 16),
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             widget.hodData["name"] ?? "HOD Name",
//                             style: const TextStyle(
//                                 fontSize: 20,
//                                 fontWeight: FontWeight.bold,
//                                 color: Colors.white),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             widget.hodData["email"] ?? "hod@email.com",
//                             style: const TextStyle(
//                                 color: Colors.white70, fontSize: 14),
//                           ),
//                           const SizedBox(height: 2),
//                           Text(
//                             widget.hodData["department"] ?? "Department",
//                             style: const TextStyle(
//                                 color: Colors.white70, fontSize: 14),
//                           ),
//                         ],
//                       ),
//                     ),
//                     IconButton(
//   icon: const Icon(Icons.logout),
//   onPressed: () {
//     AuthUtils.showLogoutDialog(context);
//   },
// ),

//                   ],
//                 ),
//               ),
//             ),

//             // const SizedBox(height: 5),

//             // Stats Cards
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: Row(
//                 children: [
//                   _dashboardCard(
//                       "Total Students", "$totalStudents", Colors.blue, Icons.people),
//                   const SizedBox(width: 12),
//                   _dashboardCard("Pending Approvals", "$pendingCount",
//                       Colors.orange, Icons.pending_actions),
//                 ],
//               ),
//             ),

//             const SizedBox(height: 17),

//             // Search
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: TextField(
//                 onChanged: (v) => setState(() => searchQuery = v),
//                 style: const TextStyle(color: Colors.black87),
//                 decoration: InputDecoration(
//                   hintText: "Search student...",
//                   prefixIcon: const Icon(Icons.search, color: Colors.grey),
//                   filled: true,
//                   fillColor: Colors.white,
//                   contentPadding: const EdgeInsets.symmetric(vertical: 0),
//                   border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(30),
//                       borderSide: BorderSide.none),
//                 ),
//               ),
//             ),

//             const SizedBox(height: 15),

//             // Tabs
//             TabBar(
//               controller: _tabController,
//               indicator: BoxDecoration(
//                   color: Colors.white, borderRadius: BorderRadius.circular(5)),
//               labelColor: Colors.black87,
//               unselectedLabelColor: Colors.white70,
//               tabs: const [
//                 Tab(text: "  New Requests  "),
//                 Tab(text: "  All students  "),
//               ],
//             ),

//             // Tab Views
//             Expanded(
//               child: TabBarView(
//                 controller: _tabController,
//                 children: [
//                   // New Requests
// // Replace this part inside TabBarView -> New Requests
// isLoading
//     ? const Center(child: CircularProgressIndicator())
//     : pendingEntries.isEmpty
//         ? const Center(
//             child: Text(
//               "No new requests",
//               style: TextStyle(color: Colors.white70),
//             ),
//           )
//         : ListView.builder(
//             itemCount: pendingEntries.length,
//             itemBuilder: (context, index) {
//               final e = pendingEntries[index];
//               return WorkRequestCard(
//                 workData: e,
//                 onApprove: () {
//                   _updateWorkStatus(e["uid"], e["title"], "approved");
//                 },
//                 onReject: () {
//                   _updateWorkStatus(e["uid"], e["title"], "rejected");
//                 },
//               );
//             },
//           ),


//                   // All Students
//                   isLoading
//                       ? const Center(child: CircularProgressIndicator())
//                       : uniqueStudents.isEmpty
//                           ? const Center(
//                               child: Text(
//                                 "No students found",
//                                 style: TextStyle(color: Colors.white70),
//                               ),
//                             )
//                           : ListView.builder(
//                               itemCount: uniqueStudents.length,
//                               itemBuilder: (context, index) {
//                                 final e = uniqueStudents[index];
//                                 if (!(e["name"] ?? "")
//                                     .toString()
//                                     .toLowerCase()
//                                     .contains(searchQuery.toLowerCase())) {
//                                   return const SizedBox.shrink();
//                                 }
//                                 return StudentCard(
//                                   data: e,
//                                   onTap: () {
//                                     Navigator.push(
//                                         context,
//                                         MaterialPageRoute(
//                                             builder: (_) => StudentDetailPage(
//                                                 studentUid: e["uid"],
//                                                 studentName: e["name"])));
//                                   },
//                                 );
//                               },
//                             ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _dashboardCard(
//       String title, String value, Color color, IconData icon) {
//     return Expanded(
//       child: Container(
//         padding: const EdgeInsets.all(16),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//               colors: [color.withOpacity(0.6), color.withOpacity(0.3)],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight),
//           borderRadius: BorderRadius.circular(20),
//           boxShadow: [
//             BoxShadow(
//                 color: color.withOpacity(0.4),
//                 blurRadius: 10,
//                 offset: const Offset(0, 4)),
//           ],
//         ),
//         child: Column(
//           children: [
//             Row(
//               children: [
//                 Icon(icon, color: color, size: 30),
//                 const SizedBox(width: 10),
//                 Text(value,
//                     style: TextStyle(
//                         fontSize: 22,
//                         fontWeight: FontWeight.bold,
//                         color: color)),
//               ],
//             ),
//             const SizedBox(height: 6),
//             Align(
//               alignment: Alignment.centerLeft,
//               child: Text(
//                 title,
//                 style: const TextStyle(color: Colors.white70),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
// class WorkRequestCard extends StatelessWidget {
//   final Map<String, dynamic> workData;
//   final VoidCallback? onApprove;
//   final VoidCallback? onReject;

//   const WorkRequestCard({
//     super.key,
//     required this.workData,
//     this.onApprove,
//     this.onReject,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final hours = workData["hours"] ?? 0;
//     final date = workData["date"] ?? "-";

//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(18),
//         boxShadow: const [
//           BoxShadow(
//             color: Colors.black12,
//             blurRadius: 8,
//             offset: Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // Work Title
//           Text(
//             workData["title"] ?? "Work Title",
//             style: const TextStyle(
//                 fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
//           ),
//           const SizedBox(height: 6),

//           // Student Name
//           Row(
//             children: [
//               const Icon(Icons.person, size: 18, color: Colors.black54),
//               const SizedBox(width: 8),
//               Text(
//                 workData["name"] ?? "Student Name",
//                 style: const TextStyle(fontSize: 14, color: Colors.black87),
//               ),
//             ],
//           ),
//           const SizedBox(height: 6),

//           // Work Hours
//           Row(
//             children: [
//               const Icon(Icons.access_time, size: 18, color: Colors.black54),
//               const SizedBox(width: 8),
//               Text(
//                 "$hours hours",
//                 style: const TextStyle(fontSize: 14, color: Colors.black87),
//               ),
//             ],
//           ),
//           const SizedBox(height: 6),

//           // Date
//           Row(
//             children: [
//               const Icon(Icons.calendar_today, size: 18, color: Colors.black54),
//               const SizedBox(width: 8),
//               Text(
//                 date,
//                 style: const TextStyle(
//                     fontSize: 14,
//                     color: Colors.black87,
//                     fontWeight: FontWeight.w500),
//               ),
//             ],
//           ),
//           const SizedBox(height: 12),

//           // Approve / Reject Buttons
//           Row(
//             mainAxisAlignment: MainAxisAlignment.end,
//             children: [
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.green,
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10))),
//                 onPressed: onApprove,
//                 child: const Text("Approve"),
//               ),
//               const SizedBox(width: 12),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.red,
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10))),
//                 onPressed: onReject,
//                 child: const Text("Reject"),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

// class StudentCard extends StatelessWidget {
//   final Map<String, dynamic> data;
//   final VoidCallback? onTap;

//   const StudentCard({
//     super.key,
//     required this.data,
//     this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final totalHours = data["totalHours"] ?? 0;

//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//         padding: const EdgeInsets.all(16),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(18),
//           boxShadow: const [
//             BoxShadow(
//               color: Colors.black12,
//               blurRadius: 8,
//               offset: Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Name
//             Text(
//               data["name"] ?? "Student Name",
//               style: const TextStyle(
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.black87),
//             ),
//             const SizedBox(height: 8),

//             // Email
//             Row(
//               children: [
//                 const Icon(Icons.email, size: 18, color: Colors.black54),
//                 const SizedBox(width: 8),
//                 Expanded(
//                   child: Text(
//                     data["email"] ?? "student@email.com",
//                     style: const TextStyle(color: Colors.black87, fontSize: 14),
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 6),

//             // Phone
//             Row(
//               children: [
//                 const Icon(Icons.phone, size: 18, color: Colors.black54),
//                 const SizedBox(width: 8),
//                 Text(
//                   data["mobile"] ?? "-",
//                   style: const TextStyle(color: Colors.black87, fontSize: 14),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 6),

//             // Total Work Hours
//             Row(
//               children: [
//                 const Icon(Icons.access_time, size: 18, color: Colors.black54),
//                 const SizedBox(width: 8),
//                 Text(
//                   " Total: $totalHours hours",
//                   style: const TextStyle(
//                       color: Colors.black87,
//                       fontSize: 14,
//                       fontWeight: FontWeight.w500),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }



import 'dart:async';
import 'studworkdetails.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:earn_and_learn_project/loginpage.dart';
import '../utils/auth_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HodDashboard extends StatefulWidget {
   final String uid;

  const HodDashboard({super.key, required this.uid});

  @override
  State<HodDashboard> createState() => _HodDashboardState();
}

class _HodDashboardState extends State<HodDashboard>
    with SingleTickerProviderStateMixin {

      late DatabaseReference _hodRef;
Map<String, dynamic>? hodData;

  final DatabaseReference _usersRef = FirebaseDatabase.instance.ref("users");
  StreamSubscription? _subscription;
void _updateWorkStatus(String uid, String title, String status) {
  final userRef = _usersRef.child(uid).child("workEntries");
  userRef.once().then((snapshot) {
    final works = Map<String, dynamic>.from(snapshot.snapshot.value as Map);
    works.forEach((key, workRaw) {
      final work = Map<String, dynamic>.from(workRaw);
      if (work["title"] == title) {
        userRef.child(key).update({"status": status});
      }
    });
  });
}

  List<Map<String, dynamic>> allEntries = [];
  List<Map<String, dynamic>> uniqueStudents = [];
  bool isLoading = true;
  String searchQuery = "";

  late TabController _tabController;

  @override
  @override
void initState() {
  super.initState();

  _tabController = TabController(length: 2, vsync: this);

  _hodRef = FirebaseDatabase.instance.ref("hods/${widget.uid}");

  _hodRef.once().then((snapshot) {
    if (snapshot.snapshot.value != null) {
      setState(() {
        hodData = Map<String, dynamic>.from(
            snapshot.snapshot.value as Map);
      });

      _listenToHodEntries();
    }
  });
}


  void _listenToHodEntries() {
   final hodDept =
(hodData?["department"] ?? "")

        .toString()
        .trim()
        .toLowerCase();


    _subscription = _usersRef.onValue.listen((event) {
      final List<Map<String, dynamic>> entriesList = [];
      final Map<String, Map<String, dynamic>> studentsMap = {};

      if (event.snapshot.value != null) {
        final users = Map<String, dynamic>.from(event.snapshot.value as Map);
        users.forEach((uid, userRaw) {
          final user = Map<String, dynamic>.from(userRaw);
          final dept =
    (user["department"] ?? "")
        .toString()
        .trim()
        .toLowerCase();

         if (dept.trim().toLowerCase() != hodDept.trim().toLowerCase()) return;

print("HOD Department: $hodDept");
print("Student Department: $dept");

          // Calculate total work hours for the student
          double totalHours = 0;
          if (user["workEntries"] != null) {
            final workEntries = Map<String, dynamic>.from(user["workEntries"]);
            workEntries.forEach((_, workRaw) {
              final work = Map<String, dynamic>.from(workRaw);
              totalHours += double.tryParse(work["hours"]?.toString() ?? "0") ?? 0;
              entriesList.add({
                "uid": uid,
                
                "name": user["name"],
                "email": user["email"],
                "mobile": user["mobile"] ?? "-",
                "department": user["department"],
                "title": work["title"],
                "hours": work["hours"] ?? 0,
                "fromTime": work["fromTime"],
                "toTime": work["toTime"],
                "workplace": work["workplace"],
                "date": work["date"],
                "status": work["status"],
              });
            });
          }

          // Store unique student with total work hours
          studentsMap[uid] = {
            "uid": uid,
            "name": user["name"],
            "email": user["email"],
            "mobile": user["mobile"] ?? "-",
            "totalHours": totalHours,
          };
        });
      }

      setState(() {
        allEntries = entriesList;
        uniqueStudents = studentsMap.values.toList();
        isLoading = false;
      });
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pendingEntries = allEntries
        .where((e) =>
            e["status"]?.toString().toLowerCase() == "pending" &&
            (e["name"] ?? "")
                .toString()
                .toLowerCase()
                .contains(searchQuery.toLowerCase()))
        .toList();

    final totalStudents = uniqueStudents.length;
    final pendingCount = pendingEntries.length;

    return Scaffold(
      backgroundColor: const Color(0xFF0B1E3D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B1E3D),
        foregroundColor: Colors.white,
        title: Text("HOD's Dashboard",style: TextStyle(fontWeight: FontWeight.bold),),
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: Column(
          children: [
            // HOD Profile Card
            Padding(
              padding: const EdgeInsets.all(16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Color(0xFF1B3A68), Color(0xFF0B1E3D)]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black45,
                        blurRadius: 10,
                        offset: Offset(0, 4))
                  ],
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white24,
                      child: Text(
                       hodData?["name"] != null
    ? hodData!["name"].toString().substring(0, 1)
    : "H"

                            "H",
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            hodData?["name"] ?? "HOD",
                            style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          const SizedBox(height: 4),
                          Text(
                           hodData?["email"] ?? "" ?? "hod@email.com",
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 14),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            hodData?["department"]  ?? "Department",
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
  icon: const Icon(Icons.logout),
  onPressed: () {
    AuthUtils.showLogoutDialog(context);
  },
),

                  ],
                ),
              ),
            ),

            // const SizedBox(height: 5),

            // Stats Cards
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _dashboardCard(
                      "Total Students", "$totalStudents", Colors.blue, Icons.people),
                  const SizedBox(width: 12),
                  _dashboardCard("Pending Approvals", "$pendingCount",
                      Colors.orange, Icons.pending_actions),
                ],
              ),
            ),

            const SizedBox(height: 17),

            // Search
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: (v) => setState(() => searchQuery = v),
                style: const TextStyle(color: Colors.black87),
                decoration: InputDecoration(
                  hintText: "Search student...",
                  prefixIcon: const Icon(Icons.search, color: Colors.grey),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(vertical: 0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: BorderSide.none),
                ),
              ),
            ),

            const SizedBox(height: 15),

            // Tabs
            TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(5)),
              labelColor: Colors.black87,
              unselectedLabelColor: Colors.white70,
              tabs: const [
                Tab(text: "  New Requests  "),
                Tab(text: "  All students  "),
              ],
            ),

            // Tab Views
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // New Requests
// Replace this part inside TabBarView -> New Requests
isLoading
    ? const Center(child: CircularProgressIndicator())
    : pendingEntries.isEmpty
        ? const Center(
            child: Text(
              "No new requests",
              style: TextStyle(color: Colors.white70),
            ),
          )
        : ListView.builder(
            itemCount: pendingEntries.length,
            itemBuilder: (context, index) {
              final e = pendingEntries[index];
              return WorkRequestCard(
                workData: e,
                onApprove: () {
                  _updateWorkStatus(e["uid"], e["title"], "approved");
                },
                onReject: () {
                  _updateWorkStatus(e["uid"], e["title"], "rejected");
                },
              );
            },
          ),


                  // All Students
                  isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : uniqueStudents.isEmpty
                          ? const Center(
                              child: Text(
                                "No students found",
                                style: TextStyle(color: Colors.white70),
                              ),
                            )
                          : ListView.builder(
                              itemCount: uniqueStudents.length,
                              itemBuilder: (context, index) {
                                final e = uniqueStudents[index];
                                if (!(e["name"] ?? "")
                                    .toString()
                                    .toLowerCase()
                                    .contains(searchQuery.toLowerCase())) {
                                  return const SizedBox.shrink();
                                }
                                return StudentCard(
                                  data: e,
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (_) => StudentDetailPage(
                                                studentUid: e["uid"],
                                                studentName: e["name"])));
                                  },
                                );
                              },
                            ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dashboardCard(
      String title, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [color.withOpacity(0.6), color.withOpacity(0.3)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 10,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 30),
                const SizedBox(width: 10),
                Text(value,
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: color)),
              ],
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                title,
                style: const TextStyle(color: Colors.white70),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class WorkRequestCard extends StatelessWidget {
  final Map<String, dynamic> workData;
  final VoidCallback? onApprove;
  final VoidCallback? onReject;

  const WorkRequestCard({
    super.key,
    required this.workData,
    this.onApprove,
    this.onReject,
  });

  @override
  Widget build(BuildContext context) {
    final hours = workData["hours"] ?? 0;
    final date = workData["date"] ?? "-";

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Work Title
          Text(
            workData["title"] ?? "Work Title",
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
          const SizedBox(height: 6),

          // Student Name
          Row(
            children: [
              const Icon(Icons.person, size: 18, color: Colors.black54),
              const SizedBox(width: 8),
              Text(
                workData["name"] ?? "Student Name",
                style: const TextStyle(fontSize: 14, color: Colors.black87),
              ),
            ],
          ),
          const SizedBox(height: 6),

          // Work Hours
          Row(
            children: [
              const Icon(Icons.access_time, size: 18, color: Colors.black54),
              const SizedBox(width: 8),
              Text(
                "$hours hours",
                style: const TextStyle(fontSize: 14, color: Colors.black87),
              ),
            ],
          ),
          const SizedBox(height: 6),

          // Date
          Row(
            children: [
              const Icon(Icons.calendar_today, size: 18, color: Colors.black54),
              const SizedBox(width: 8),
              Text(
                date,
                style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                    fontWeight: FontWeight.w500),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Approve / Reject Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                onPressed: onApprove,
                child: const Text("Approve"),
              ),
              const SizedBox(width: 12),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                onPressed: onReject,
                child: const Text("Reject"),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class StudentCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback? onTap;

  const StudentCard({
    super.key,
    required this.data,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final totalHours = data["totalHours"] ?? 0;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Name
            Text(
              data["name"] ?? "Student Name",
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
            const SizedBox(height: 8),

            // Email
            Row(
              children: [
                const Icon(Icons.email, size: 18, color: Colors.black54),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    data["email"] ?? "student@email.com",
                    style: const TextStyle(color: Colors.black87, fontSize: 14),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),

            // Phone
            Row(
              children: [
                const Icon(Icons.phone, size: 18, color: Colors.black54),
                const SizedBox(width: 8),
                Text(
                  data["mobile"] ?? "-",
                  style: const TextStyle(color: Colors.black87, fontSize: 14),
                ),
              ],
            ),
            const SizedBox(height: 6),

            // Total Work Hours
            Row(
              children: [
                const Icon(Icons.access_time, size: 18, color: Colors.black54),
                const SizedBox(width: 8),
                Text(
                  " Total: $totalHours hours",
                  style: const TextStyle(
                      color: Colors.black87,
                      fontSize: 14,
                      fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
